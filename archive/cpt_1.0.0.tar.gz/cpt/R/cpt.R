


#' Change Point Test
#' 
#' Detecting change points in animal ranging data
#'
#' @param xyt a matrix with columns x, y (in cartesian coordinates) and t
#' @param alpha nominal significance level
#' @param q q value
#' @param N total number of permutations
#' @param tol maximum distance between indistinguishable positions
#'
#' @return TODO
#' @export
change_point_test <- function(xyt, alpha = 0.05, q = 4, N = 1000, tol = 0, nbatches = 10) {
  # # xyt
  # alpha = 0.05
  # q = 4
  # N = 1000
  # tol = 0
  # tol = 0.0001
  
  # reverse order
  b_xyt <- xyt[NROW(xyt):1,]
  # calcuate diff of coordinates
  b_xy_diff <- structure(apply(b_xyt[, 1:2], 2, FUN = diff), dimnames = list(NULL,c("x_diff", "y_diff")))
  # remove points at which animal stays still
  ind_new <- c(TRUE, sqrt(b_xy_diff[, "x_diff"]^2 + b_xy_diff[, "y_diff"]^2) > tol)
  b_xyt2 <- b_xyt[ind_new,]
  
  set.seed(2025)
  sig <- drop(rcpparma_change_point_test_fit(bz1 = b_xyt2[, "x"], bz2 = b_xyt2[, "y"], q = q, N = N, alpha = alpha)) #FIXME bz1 and bz2
  
  # if alpha is null, that means we want return the probabilities accross k
  if(is.null(alpha)) return(sig)
  
  #  Remove putative goal from list of CP’s
  sig[1] <- 0
  b_xyt2 <- cbind(b_xyt2,
                  "sig" = sig,
                  "cp_no" = ifelse(sig == 0, 0, cumsum(sig)))
  colnames(b_xyt2)[4:5]
  
  # re-index - merge with b_xyt
  b_xyt <- merge(b_xyt, b_xyt2[, c("t", "sig")], by = "t", all.x = TRUE, sort = FALSE)
  # b_xyt <- b_xyt[rev(order(b_xyt[,"t"])), ]
  xyt <- b_xyt[order(b_xyt[,"t"]), ]
  sig_tmp <- 
    xyt[, "cp_no"] <- ifelse(is.na(xyt[, "sig"]), NA,
                             ifelse(xyt[, "sig"] == 0, 0, cumsum(na.fill(xyt[, "sig"], fill = 0))))
  #na.locf
  xyt[, "sig"] <- na.locf(xyt[, "sig"], fromLast = TRUE, na.rm = FALSE)
  xyt[, "cp_no"] <- na.locf(xyt[, "cp_no"], fromLast = TRUE, na.rm = FALSE)
  
  return(xyt)
}
