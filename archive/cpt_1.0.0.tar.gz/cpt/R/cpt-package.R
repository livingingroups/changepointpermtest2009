#' mypackage: A package for computating the notorious bar statistic.
#'
#' The mypackage package provides three categories of important functions:
#' foo, bar and baz.
#' 
#' @section Mypackage functions:
#' The mypackage functions ...
#'
#' @docType cpt
#' @name cpt
#' @useDynLib cpt
NULL 


#' @import checkmate
#' @import xts
#' @import zoo
#' @import trackframe
#' @importFrom stats runif
#' @importFrom dqrng dqsample

NULL

#' Data Extracted from Figures
#'
#' These data were extracted from Figures 3,4,7 of Byrne, Noser, Bates, Jupp 2009
#' Since the process of pulling data from an image is error-prone, these data should **not**
#' be used for scientific inference. Especially the track in 7a is almost certainly
#' substantially different from the original.
"cptfiguredata"

