// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppArmadillo.h which pulls Rcpp.h in for us
#include "RcppArmadillo.h"

// via the depends attribute we tell Rcpp to create hooks for
// RcppArmadillo so that the build process will know what to do
//
// [[Rcpp::depends(RcppArmadillo)]]

// simple example of creating two matrices and
// returning the result of an operatioon on them
//
// via the exports attribute we tell Rcpp to make this function
// available from R
//
// [[Rcpp::export]]
arma::dvec rcpparma_change_point_test_fit(arma::dvec bz1, arma::dvec bz2, int32_t q, int32_t N, double alpha) {
    // arma::arma_rng::set_seed(2025);

    int32_t nz = bz1.n_elem;
    
    // Calculate the steps (differences between consecutive points)
    arma::dvec bz1diff = arma::diff(bz1);
    arma::dvec bz2diff = arma::diff(bz2);
    
    // Initialize variables
    int32_t goal_no = 1;                   // Start with goal_no = 1
    int32_t last_no = nz;                  // Last position of interest
    
    // Pre-allocate vectors
    arma::dvec Rsumrand(N, arma::fill::zeros);  // Store random permutation statistics
    arma::dvec Pr(nz, arma::fill::ones);        // Store p-values
    arma::dvec sig(nz, arma::fill::zeros);      // Indicator for change points

    // Main loop: look sequentially for next possible change point
    while (goal_no < last_no - q) {
        int32_t k = 0;
        
        // Reset p-values for this iteration
        Pr.fill(1.0);
        
        // Initial p-value
        double P = 1.0;
        
        // Increase k until next possible change point is found
        while ((P > alpha) && (goal_no + q + k < last_no)) {
            k++;
            
            // Calculate distances
            double R1 = std::sqrt(std::pow(bz1(goal_no+k-1) - bz1(goal_no-1), 2) + 
                                 std::pow(bz2(goal_no+k-1) - bz2(goal_no-1), 2));
            double R2 = std::sqrt(std::pow(bz1(goal_no+k+q-1) - bz1(goal_no+k-1), 2) + 
                                 std::pow(bz2(goal_no+k+q-1) - bz2(goal_no+k-1), 2));
            
            double Rsum = R1 + R2;
            
            // Observed value of statistic R1 + R2
            Rsumrand(0) = Rsum;
            
            // Calculate statistic R1 + R2 for N-1 random permutations
            for (int32_t it = 1; it < N; it++) {
                // Generate random permutation
                arma::dvec u = arma::randu<arma::dvec>(k+q);
                arma::uvec perm = arma::sort_index(u);
                
                // Initialize random coordinates
                double bz1r = bz1(goal_no-1);
                double bz2r = bz2(goal_no-1);
                
                // Apply permutation
                for (int32_t j = 0; j < k; j++) {
                    bz1r += bz1diff(goal_no-1+perm(j));
                    bz2r += bz2diff(goal_no-1+perm(j));
                }
                
                // Calculate distances for permuted points
                double R1rand = std::sqrt(std::pow(bz1r - bz1(goal_no-1), 2) + 
                                         std::pow(bz2r - bz2(goal_no-1), 2));
                double R2rand = std::sqrt(std::pow(bz1(goal_no+k+q-1) - bz1r, 2) + 
                                         std::pow(bz2(goal_no+k+q-1) - bz2r, 2));
                
                Rsumrand(it) = R1rand + R2rand;
            }
            
            // Calculate p-value
            P = arma::sum(Rsumrand >= Rsum) / static_cast<double>(N);
            
            // Store p-value
            Pr(k-1) = P;
        }
        
        // f is the first value of k in the current run that is significant
        int32_t f = k;
        
        // Continue increasing k to find the last significant value
        while ((P <= alpha) && (goal_no + q + k < last_no)) {
            k++;
            
            // Calculate distances
            double R1 = std::sqrt(std::pow(bz1(goal_no+k-1) - bz1(goal_no-1), 2) + 
                                 std::pow(bz2(goal_no+k-1) - bz2(goal_no-1), 2));
            double R2 = std::sqrt(std::pow(bz1(goal_no+k+q-1) - bz1(goal_no+k-1), 2) + 
                                 std::pow(bz2(goal_no+k+q-1) - bz2(goal_no+k-1), 2));
            
            double Rsum = R1 + R2;
            
            // Observed value of statistic R1 + R2
            Rsumrand(0) = Rsum;
            
            // Calculate statistic R1 + R2 for N-1 random permutations
            for (int32_t it = 1; it < N; it++) {
                // Generate random permutation
                arma::dvec u = arma::randu<arma::dvec>(k+q);
                arma::uvec perm = arma::sort_index(u);
                
                // Initialize random coordinates
                double bz1r = bz1(goal_no-1);
                double bz2r = bz2(goal_no-1);
                
                // Apply permutation
                for (int32_t j = 0; j < k; j++) {
                    bz1r += bz1diff(goal_no-1+perm(j));
                    bz2r += bz2diff(goal_no-1+perm(j));
                }
                
                // Calculate distances for permuted points
                double R1rand = std::sqrt(std::pow(bz1r - bz1(goal_no-1), 2) + 
                                         std::pow(bz2r - bz2(goal_no-1), 2));
                double R2rand = std::sqrt(std::pow(bz1(goal_no+k+q-1) - bz1r, 2) + 
                                         std::pow(bz2(goal_no+k+q-1) - bz2r, 2));
                
                Rsumrand(it) = R1rand + R2rand;
            }
            
            // Calculate p-value
            P = arma::sum(Rsumrand >= Rsum) / static_cast<double>(N);
            
            // Store p-value
            Pr(k-1) = P;
        }
        
        // l is the last value of k in the current run that is significant
        int32_t l = k - 1;
        
        // Apply "peak rule"
        int32_t rmin = 0;
        if (l >= f) {
            // Extract the p-values for the significant range
            arma::dvec Pr_sub = Pr.subvec(f-1, l-1);
            
            // Find the index of the minimum p-value
            rmin = arma::index_min(Pr_sub) + 1;
        }
        
        // Update goal_no
        if (rmin > 0) {
            goal_no = goal_no + f + rmin - 1;
            sig(goal_no-1) = 1;  // Mark as change point
        } else {
            goal_no = last_no;  // Exit condition
        }
    }
    return sig;
}
